# Fighting Ghosts

In this Flashpoint you will follow the story of Gray Death Legion participation in the war of 3039. You will need to demonstrate all your command skills while facing the same circumstances as the legendary Mercenary unit.

## Features

* Custom Gray Death Legion mechs
* Lore accurate lances and mechwarriors 
* Story branches depending on how you complete your first mission

## Dependencies

This version of the Flashpoint works only with RogueTech mod.

## Installation

This folder (fp_fightingGhosts) needs to be dropped into the Battletech/Mods folder and you are all set to go.

## Authors

* **Anatolii Iakimets** - *ablomis@gmail.com* 

## License

This project is licensed under GPLv3 License

## Acknowledgments

* Amechwarrior for providing a great guide on how to make a Flashpoint
* RogueTech community for being awesome folks

